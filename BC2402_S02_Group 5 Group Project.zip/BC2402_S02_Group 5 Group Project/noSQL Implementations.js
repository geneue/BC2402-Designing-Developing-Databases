use "greenWorld2022"

/*Q1*/
db.owid_energy_data.distinct("country",{$and:[{"iso_code":{$ne:""}},{"iso_code":{$not:/^OWID.*/}}]}).length

/*Q2i*/
db.owid_energy_data.aggregate([{$group : {_id : null, latest_year : {$max : "$year"}, earliest_year: {$min:'$year'}}}])

/*Q2ii*/
db.owid_energy_data.aggregate([
    {$group : {_id : {country: '$country'},
    max:{$max:'$year'}, min:{$min:'$year'},
    num_records: {$sum:1}}},
    {$sort:{"country":1,max:-1, min:1}},
    {$limit:49}]);

/*Q3*/
db.owid_energy_data.aggregate([
    {$match:{"country":"Singapore"}},
    {$match:{"fossil_share_energy":{$ne:"100.0"}}},
    {$project:{
        year:{$toInt:"$year"},
        country:1,
        fossil_share_energy:{$convert:{input:"$fossil_share_energy", to:"double",onError:0}},
        biofuel_share_energy:{$convert:{input:"$biofuel_share_energy", to:"double",onError:0}},
        coal_share_energy:{$convert:{input:"$coal_share_energy", to:"double",onError:0}},
        fossil_share_energy:{$convert:{input:"$fossil_share_energy", to:"double",onError:0}},
        gas_share_energy:{$convert:{input:"$gas_share_energy", to:"double",onError:0}},
        hydro_share_energy:{$convert:{input:"$hydro_share_energy", to:"double",onError:0}},
        low_carbon_share_energy:{$convert:{input:"$low_carbon_share_energy", to:"double",onError:0}},
        nuclear_share_energy:{$convert:{input:"$nuclear_share_energy", to:"double",onError:0}},
        oil_share_energy:{$convert:{input:"$oil_share_energy", to:"double",onError:0}},
        other_renewables_share_energy:{$convert:{input:"$other_renewables_share_energy", to:"double",onError:0}},
        renewables_share_energy:{$convert:{input:"$renewables_share_energy", to:"double",onError:0}},
        solar_share_energy:{$convert:{input:"$solar_share_energy", to:"double",onError:0}},
        wind_share_energy:{$convert:{input:"$wind_share_energy", to:"double",onError:0}},
        }}
    ])

/*Q4*/
db.owid_energy_data.aggregate([
    {$match:{"country":{$in:["Brunei", "Cambodia", "Indonesia", "Laos", "Malaysia", "Myanmar", "Philippines", "Singapore", "Thailand", "Vietnam"]}}},
    {$project:{_id:0,
                "year":{$convert:{input: "$year", to: "int"}},
                "gdp":{$convert:{input: "$gdp", to: "double", onError:0}},
                country:1}},
    {$match:{"year":{$gte:2000, $lte:2021}}},
    {$match:{"gdp": {$ne:0}}},
    {$group:{_id:"$country", avgGDP: {$avg:"$gdp"}}},
    {$sort: {avgGDP:-1}}
])    

/*Q5*/
db.owid_energy_data.aggregate([
    {$match: {"country":{$in:["Brunei", "Cambodia", "Indonesia", "Myanmar", "Laos", "Malaysia", "Philippines", "Singapore", "Thailand", "Vietnam"]}}},
    {$project: {_id: 0, year: {$convert: {input: "$year", to: "int"}}, country: 1, 
        gdp: {$convert: {input: "$gdp", to: "double", onError: 0}},
        oil_consumption: {$convert: {input: "$oil_consumption", to: "double", onError:0}}
    }},
    {$match: {"year": {$gte: 2000, $lte: 2021}}},
    {$setWindowFields:{
        partitionBy: "$country",
        sortBy: {"year": 1},
        output: {
            moving_avg_oil_consumption: {$avg: "$oil_consumption", window: {range:[-2,0]}},
          moving_avg_gdp: {$avg: "$gdp", window: {range:[-2, 0]}}
        }
    }},
    {$project: {_id:0, country:1, year:1,
    moving_avg_oil_consumption: {$cond: {if: {$lt: ["$year", 2002]}, then: 0, else: "$moving_avg_oil_consumption"}},
    moving_avg_gdp: {$cond: {if: {$lt: ["$year", 2002]}, then: 0, else: "$moving_avg_gdp"}}}},
    
    {$setWindowFields:{
        partitionBy: "$country",
        sortBy: {"year": 1},
        output: {
            previous_moving_avg_oil_cnsmpt: {$shift: {output: "$moving_avg_oil_consumption", by: -1, default: 0}},
            
        }
    }},
    {$project: {country: 1, year: 1, moving_avg_oil_consumption: 1, moving_avg_gdp: 1, previous_moving_avg_oil_cnsmpt: 1, 
        difference_with_previous_moving_avg_oil: {$subtract: ["$moving_avg_oil_consumption", "$previous_moving_avg_oil_cnsmpt"]}}}, 
    {$match: {difference_with_previous_moving_avg_oil: {$lt: 0}}},
    {$project: {previous_moving_avg_oil_cnsmpt: 0}}
]);


/*Q6*/
/* For imports */
db.importsofenergyproducts.aggregate([ 
 { 
     $project: { 
         energy_products: 1, 
         sub_products: 1, 
         value_ktoe: {$toDouble: "$value_ktoe"} 
     } 
 }, 
 { 
     $group: { 
         _id: { 
             energy_products: "$energy_products", 
             sub_products: "$sub_products" 
         }, 
         avg_ktoe: {$avg: "$value_ktoe"} 
     } 
 } 
]) 

/* For exports */
db.exportsofenergyproducts.aggregate([ 
 { 
  $project: { 
         energy_products: 1, 
         sub_products: 1, 
         value_ktoe: {$toDouble: "$value_ktoe"} 
     } 
 }, 
 { 
     $group: { 
         _id: { 
             energy_products: "$energy_products", 
             sub_products: "$sub_products" 
         }, 
         avg_ktoe: {$avg: "$value_ktoe"} 
     } 
 } 
]) 
 
db.exportsofenergyproducts.aggregate([ 
 { 
     $project: { 
         energy_products: 1, 
         sub_products: 1, 
         value_ktoe: {$toDouble: "$value_ktoe"} 
     } 
 }, 
 { 
     $group: { 
         _id: { 
             energy_products: "$energy_products", 
             sub_products: "$sub_products" 
         }, 
         avg_ktoe: {$avg: "$value_ktoe"} 
     } 
 } 
]) 

/*Q7*/
/* Yearly Difference */
db.importsofenergyproducts.aggregate([ 
 { 
     $lookup: 
         { 
             from: "exportsofenergyproducts", 
     let: { 
                 energy_products: "$energy_products", 
                 sub_products: "$sub_products", 
                 year: "$year", 
             }, 
             pipeline: [ 
                 { 
                     $match: { 
                         $expr: { 
                             $and: [ 
                                 {$eq: ["$energy_products", "$$energy_products"]}, 
                                 {$eq: ["$sub_products", "$$sub_products"]}, 
                                 {$eq: ["$year", "$$year"]}, 
                             ] 
                         } 
                     } 
                 }, 
                 { 
                     $project: { 
                         energy_products: 1, sub_products: 1, year: 1, value_ktoe: {$toDouble: "$value_ktoe"}, _id: 0 
                     } 
                 } 
             ], 
             as: "exportsdata" 
         } 
 }, 
 { 
     $project: { 
         energy_products: 1, 
         sub_products: 1, 
         import_ktoe: {$toDouble: "$value_ktoe"}, 
         export_ktoe: {$first: "$exportsdata.value_ktoe"}, 
         year: 1 
     } 
 }, 
 { 
     $addFields: { 
         export_sub_import: {$subtract: ['$export_ktoe', '$import_ktoe']}, 
     } 
 }, 
]) 
 
/* Years where exports > imports for more than 4 instances */
db.importsofenergyproducts.aggregate([ 
 { 
     $lookup: 
         { 
             from: "exportsofenergyproducts", 
             let: { 
                 energy_products: "$energy_products", 
                 sub_products: "$sub_products", 
                 year: "$year", 
             }, 
             pipeline: [ 
                 { 
                     $match: { 
                         $expr: { 
                             $and: [ 
                                 {$eq: ["$energy_products", "$$energy_products"]}, 
                                 {$eq: ["$sub_products", "$$sub_products"]}, 
                                 {$eq: ["$year", "$$year"]},
] 
                         } 
                     } 
                 }, 
                 { 
                     $project: { 
                         energy_products: 1, sub_products: 1, year: 1, value_ktoe: {$toDouble: "$value_ktoe"}, _id: 0 
                     } 
                 } 
             ], 
             as: "exportsdata" 
         } 
 }, 
 { 
     $project: { 
         energy_products: 1, 
         sub_products: 1, 
         import_ktoe: {$toDouble: "$value_ktoe"}, 
         export_ktoe: {$first: "$exportsdata.value_ktoe"}, 
         year: 1 
     } 
 }, 
 { 
     $addFields: { 
         export_sub_import: {$subtract: ['$export_ktoe', '$import_ktoe']}, 
         export_gt_import: {$gt: ['$export_ktoe', '$import_ktoe']}, 
     } 
 }, 
 { 
     $group: { 
         _id: "$year", 
         export_gt_import_count: {$sum: {$cond: ["$export_gt_import", 1, 0]}} 
     } 
 }, 
 { 
     $match: { 
         export_gt_import_count: {$gt: 4} 
     } 
 } 
])

/*Q8*/
db.householdelectricityconsumption.aggregate([
    {$match: {$and:[{"Region":{$not:/^Overall.*/}}, {"dwelling_type":{$not:/^Overall.*/}},
    {"month":"Annual"},{"kwh_per_acc":{$not:/^s.*/}}]}},
    {$group: {_id: {"year":"$year", "Region": "$Region"},
    average_kwh_per_acc: {$avg: {$convert:{input: {$trim: {input: "$kwh_per_acc"}}, to: "decimal"}}}
    }},
    {$sort: {_id: 1}}
    ])


/*Q9*/

// To find distinct regions excluding "overall"
db.householdelectricityconsumption.distinct(["Region"])

db.householdelectricityconsumption.aggregate([
    {$facet:{
    "Central":[
        {$match:{"month": "Annual"}},
        {$match:{"Region": "Central Region"}},
        {$project:{_id:0,
                    Region:1,
                    "year":{$convert:{input: "$year", to: "int"}},
                    "kwh_per_acc":{$convert:
                                     {input: 
                                        {$trim:{input:"$kwh_per_acc",chars:"\r"}}, to: "double", onError:0}}}},
        {$group:{_id:{Region:"$Region",year:"$year"}, average_kwh_per_acc: {$avg:"$kwh_per_acc"}}},
        {$setWindowFields:{
        partitionBy: "$Region",
        sortBy: {"year": 1}
        output: {
        prev_year_average: {
            $shift: {output: "$average_kwh_per_acc", by: -1, default: 0}}}}},
        {$addFields:{
            "moving_2_year_avg_diff":{
                $subtract: ["$average_kwh_per_acc", "$prev_year_average"]}}},
        {$addFields:{
            "no_of_negatives":{
                $cond: [{$lt:["$moving_2_year_avg_diff", 0]},1,0]}}},
        {$group:{_id:"Central Region","total_no_of_negatives": {$sum:"$no_of_negatives"}}}
        ],
    "East":[
    {$match:{"month": "Annual"}},
    {$match:{"Region": "East Region"}},
    {$project:{_id:0,
                Region:1,
                "year":{$convert:{input: "$year", to: "int"}},
                "kwh_per_acc":{$convert:
                                 {input: 
                                    {$trim:{input:"$kwh_per_acc",chars:"\r"}}, to: "double", onError:0}}}},
    {$group:{_id:{Region:"$Region",year:"$year"}, average_kwh_per_acc: {$avg:"$kwh_per_acc"}}},
    {$setWindowFields:{
        partitionBy: "$Region",
        sortBy: {"year": 1}
        output: {
        prev_year_average: {
            $shift: {output: "$average_kwh_per_acc", by: -1, default: 0}}}}},
    {$addFields:{
        "moving_2_year_avg_diff":{
            $subtract: ["$average_kwh_per_acc", "$prev_year_average"]}}},
    {$addFields:{
        "no_of_negatives":{
            $cond: [{$lt:["$moving_2_year_avg_diff", 0]},1,0]}}},
    {$group:{_id:"East Region","total_no_of_negatives": {$sum:"$no_of_negatives"}}}
        ],
    "North East":[
    {$match:{"month": "Annual"}},
    {$match:{"Region": "North East Region"}},
    {$project:{_id:0,
                Region:1,
                "year":{$convert:{input: "$year", to: "int"}},
                "kwh_per_acc":{$convert:
                                 {input: 
                                    {$trim:{input:"$kwh_per_acc",chars:"\r"}}, to: "double", onError:0}}}},
    {$group:{_id:{Region:"$Region",year:"$year"}, average_kwh_per_acc: {$avg:"$kwh_per_acc"}}},
    {$setWindowFields:{
        partitionBy: "$Region",
        sortBy: {"year": 1}
        output: {
        prev_year_average: {
            $shift: {output: "$average_kwh_per_acc", by: -1, default: 0}}}}},
    {$addFields:{
        "moving_2_year_avg_diff":{
            $subtract: ["$average_kwh_per_acc", "$prev_year_average"]}}},
    {$addFields:{
        "no_of_negatives":{
            $cond: [{$lt:["$moving_2_year_avg_diff", 0]},1,0]}}},
    {$group:{_id:"North East Region","total_no_of_negatives": {$sum:"$no_of_negatives"}}}
        ], 
    "North":[
    {$match:{"month": "Annual"}},
    {$match:{"Region": "North Region"}},
    {$project:{_id:0,
                Region:1,
                "year":{$convert:{input: "$year", to: "int"}},
                "kwh_per_acc":{$convert:
                                 {input: 
                                    {$trim:{input:"$kwh_per_acc",chars:"\r"}}, to: "double", onError:0}}}},
    {$group:{_id:{Region:"$Region",year:"$year"}, average_kwh_per_acc: {$avg:"$kwh_per_acc"}}},
    {$setWindowFields:{
        partitionBy: "$Region",
        sortBy: {"year": 1}
        output: {
        prev_year_average: {
            $shift: {output: "$average_kwh_per_acc", by: -1, default: 0}}}}},
    {$addFields:{
        "moving_2_year_avg_diff":{
            $subtract: ["$average_kwh_per_acc", "$prev_year_average"]}}},
    {$addFields:{
        "no_of_negatives":{
            $cond: [{$lt:["$moving_2_year_avg_diff", 0]},1,0]}}},
    {$group:{_id:"North Region","total_no_of_negatives": {$sum:"$no_of_negatives"}}}
        ], 
    "West":[
    {$match:{"month": "Annual"}},
    {$match:{"Region": "West Region"}},
    {$project:{_id:0,
                Region:1,
                "year":{$convert:{input: "$year", to: "int"}},
                "kwh_per_acc":{$convert:
                                 {input: 
                                    {$trim:{input:"$kwh_per_acc",chars:"\r"}}, to: "double", onError:0}}}},
    {$group:{_id:{Region:"$Region",year:"$year"}, average_kwh_per_acc: {$avg:"$kwh_per_acc"}}},
    {$setWindowFields:{
        partitionBy: "$Region",
        sortBy: {"year": 1}
        output: {
        prev_year_average: {
            $shift: {output: "$average_kwh_per_acc", by: -1, default: 0}}}}},
    {$addFields:{
        "moving_2_year_avg_diff":{
            $subtract: ["$average_kwh_per_acc", "$prev_year_average"]}}},
    {$addFields:{
        "no_of_negatives":{
            $cond: [{$lt:["$moving_2_year_avg_diff", 0]},1,0]}}},
    {$group:{_id:"West Region","total_no_of_negatives": {$sum:"$no_of_negatives"}}}
        ]
    }},
    {$project: {
        all: {$concatArrays: ["$Central", "$East", "$North East", "$North", "$West"]}}},
    {$unwind: "$all"},
    {$sort:{"all.total_no_of_negatives": -1}},
    {$limit: 3}   
    ])


/*Q10*/
db.householdelectricityconsumption.deleteMany({month:{$in:[
    "Annual"]}
})

db.householdelectricityconsumption.deleteMany({Region:{$in:[
    "Overall"]}
})

db.householdelectricityconsumption.deleteMany({kwh_per_acc:{$in:[
    "s\r"]}
})

    db.householdelectricityconsumption.aggregate([
    {$addFields:
        {kwh_per_acc: {$trim: {input: "$kwh_per_acc", chars:"!\r"}}}},
    {$addFields:
        {convertedmonth:{$toInt:"$month"},
        convertedavg:{$convert:{input: "$kwh_per_acc", to: "double",onError:0 }},}},
    {$group:
        {_id:{
                year:"$year",
                Region:"$Region",
                quarter:{$ceil:{$divide:["$convertedmonth",3]}}
        },
    avg_kwh_per_acc:{$avg:"$convertedavg"}}},
    {$match:{"Region":{$ne:"Overall"}}},
    {$project:{_id:0,year:"$_id.year",Region:"$_id.Region",quarter:"$_id.quarter",avg_kwh_per_acc:1}},
    {$sort:{quarter:1,year:1}}
    ])

/*Q11*/
db.householdtowngasconsumption.deleteMany({month:{$in:
['West Region','Central Region', 'North East Region','East Region','North Region','na']}});

db.householdtowngasconsumption.deleteMany({sub_housing_type:{$in:['Overall']}});

db.householdtowngasconsumption.aggregate([
    { 
    $addFields: { 
      avg_mthly_hh_tg_consp_kwh: {$trim: { input: "$avg_mthly_hh_tg_consp_kwh", chars: "!\r" }}}},
    {  $addFields:{convertedmonth:{$toInt:"$month"},
        convertedavg:{$toDecimal:"$avg_mthly_hh_tg_consp_kwh"},
    }},
       { 
         $group: {
            _id:{
                year:'$year',
                sub_housing_type: '$sub_housing_type',
                quarter:{$ceil:{$divide:["$convertedmonth",3]}}
            },
        avg: {$avg:"$convertedavg"}
        }
    },
    {$match:{"sub_housing_type":{$not:/^Overall.*/}}},
    {$project:{_id:0, year:"$_id.year",sub_housing_type:"$_id.sub_housing_type", quarter: "$_id.quarter", avg:1}},
    {$sort: {quarter: 1, year:1}}])



/*Q15*/
/* CO2 EMISSIONS across all sectors Singapore */
db.co2_emissions.aggregate([ 
    {$addFields: {sum_all_sectors: {$add:["$2010","$2011","$2012","$2013","$2014","$2015","$2016","$2017","$2018","$2019"]}}}, 
    {$match: {$and:[{"Country":"Singapore"},{"Gas":"CO2"},{sum_all_sectors:{$ne:0}}]}}, 
    {$group: {_id: {"Country":"$Country"}, avg_2010:{$avg:"$2010"},avg_2011:{$avg:"$2011"},avg_2012:{$avg:"$2012"}, 
    avg_2013:{$avg:"$2013"},avg_2014:{$avg:"$2014"},avg_2015:{$avg:"$2015"},avg_2016:{$avg:"$2016"}, 
    avg_2017:{$avg:"$2017"},avg_2018:{$avg:"$2018"},avg_2019:{$avg:"$2019"}}} 
    ])
    
/* CO2 EMISSIONS across all sectors Singapore */
db.co2_emissions.aggregate([ 
    {$addFields: {sum_all_sectors: {$add:["$2010","$2011","$2012","$2013","$2014","$2015","$2016","$2017","$2018","$2019"]}}}, 
    {$match: {$and:[{"Country":"World"},{"Gas":"CO2"},{sum_all_sectors:{$ne:0}}]}}, 
    {$group: {_id: {"Country":"$Country"}, avg_2010:{$avg:"$2010"},avg_2011:{$avg:"$2011"},avg_2012:{$avg:"$2012"}, 
    avg_2013:{$avg:"$2013"},avg_2014:{$avg:"$2014"},avg_2015:{$avg:"$2015"},avg_2016:{$avg:"$2016"}, 
    avg_2017:{$avg:"$2017"},avg_2018:{$avg:"$2018"},avg_2019:{$avg:"$2019"}}} 
    ]) 

/* GHG EMISSIONS across all sectors Singapore */
db.all_ghg_emissions.aggregate([ 
    {$addFields: {sum_all_sectors: {$add:["$2010","$2011","$2012","$2013","$2014","$2015","$2016","$2017","$2018","$2019"]}}}, 
    {$match: {$and:[{"Country":"Singapore"},{"Gas":"All GHG"},{sum_all_sectors:{$ne:0}}]}}, 
    {$group: {_id: {"Country":"$Country"}, avg_2010:{$avg:"$2010"},avg_2011:{$avg:"$2011"},avg_2012:{$avg:"$2012"}, 
    avg_2013:{$avg:"$2013"},avg_2014:{$avg:"$2014"},avg_2015:{$avg:"$2015"},avg_2016:{$avg:"$2016"}, 
    avg_2017:{$avg:"$2017"},avg_2018:{$avg:"$2018"},avg_2019:{$avg:"$2019"}}} 
    ])

/* GHG EMISSIONS across all sectors World */    
db.all_ghg_emissions.aggregate([ 
    {$addFields: {sum_all_sectors: {$add:["$2010","$2011","$2012","$2013","$2014","$2015","$2016","$2017","$2018","$2019"]}}}, 
    {$match: {$and:[{"Country":"World"},{"Gas":"All GHG"},{sum_all_sectors:{$ne:0}}]}}, 
    {$group: {_id: {"Country":"$Country"}, avg_2010:{$avg:"$2010"},avg_2011:{$avg:"$2011"},avg_2012:{$avg:"$2012"}, 
    avg_2013:{$avg:"$2013"},avg_2014:{$avg:"$2014"},avg_2015:{$avg:"$2015"},avg_2016:{$avg:"$2016"}, 
    avg_2017:{$avg:"$2017"},avg_2018:{$avg:"$2018"},avg_2019:{$avg:"$2019"}}} 
    ])    

/* Average Annual Temperature Singapore */    
db.sgp_monthly_temp.aggregate([
    {$match: {$and:[{year:{$gte:2010}},{year:{$lte:2019}}]}}, 
    {$group: {_id: {"year":"$year"}, avg_mean_temp:{$avg:"$mean_temp"}}},
    {$sort: {_id:1}}
   ])
   
/* Average Annual Temperature World */    
db.world_yearly_temp.aggregate([
    {$sort: {Year:1}}
    ])
    
/* Sea Level World */
db.sealevel.aggregate([
    {$match: {$and:[{Year:{$gte:2010}},{Year:{$lte:2019}}]}}, 
    {$group: {_id: {"Year":"$Year"}, avg_GMSL_GIA:{$avg:"$GMSL_GIA"}}},
    {$sort: {_id:1}}
   ])
