-- Q1
SELECT count(distinct country) as num_countries
FROM owid_energy_data
where iso_code != '' and iso_code not like 'OWID%';

-- Q2i
select min(year) as earliest_year, max(year) as latest_year
from owid_energy_data;

-- Q2ii
SELECT country, max(year) as max, min(year) as min, max(year) - min(year) + 1 as num_records
FROM owid_energy_data
group by country
having max(year) = 2021 and min(year) = 1900;

-- Q3
# list of columns that contains "_share_energy" --> to get a list of the new sources of energy
select column_name
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME='owid_energy_data' 
and column_name like '%_share_energy';

select country, cast(year as year) year, cast(fossil_share_energy as double) fossil_share_energy, 
cast(biofuel_share_energy as double) biofuel_share_energy, cast(coal_share_energy as double) coal_share_energy, 
cast(fossil_share_energy as double) fossil_share_energy, cast(gas_share_energy as double) gas_share_energy, 
cast(hydro_share_energy as double) hydro_share_energy, cast(low_carbon_share_energy as double) low_carbon_share_energy, 
cast(nuclear_share_energy as double) nuclear_share_energy, cast(oil_share_energy as double) oil_share_energy, 
cast(other_renewables_share_energy as double) other_renewables_share_energy,cast(renewables_share_energy as double) renewables_share_energy, 
cast(solar_share_energy as double) solar_share_energy, cast(wind_share_energy as double) wind_share_energy
from owid_energy_data
where country = "Singapore"
and cast(fossil_share_energy as double) != 100 ;

-- Q4
select country, avg(NULLIF(cast(gdp as double),0)) average_GDP
from owid_energy_data
where country in ("Brunei", "Cambodia", "Indonesia", "Laos", "Malaysia", "Myanmar", "Philippines", "Singapore", "Thailand", "Vietnam") 
and year >= 2000  and year <= 2021
group by country
order by avg(gdp) desc;
-- Brunei has NULL average GDP as there is no GDP data in the the dataset

-- Q5
select x.country, x.year start_date, (x.year + 2) end_date,
       x.moving_avg_oil,
       case when x.moving_avg_oil <= ifnull(y.moving_avg_oil,0) then '-'
       else '+' end oil_consumption_change,
       case when x.moving_avg_oil <= ifnull(y.moving_avg_oil,0) then x.moving_avg_gdp
       else "No negative change in moving average oil consumption" end moving_avg_gdp
from 
	 (select a.country, a.year,
             avg(ifnull(z.oil_consumption,0)) moving_avg_oil,
             avg(ifnull(z.gdp,0)) moving_avg_gdp
      from owid_energy_data a
      left join owid_energy_data z 
		on a.country = z.country
		and z.year between (a.year) and (a.year + 2)
		WHERE a.country IN ("Brunei", "Cambodia", "Indonesia", "Myanmar", "Laos", "Malaysia", "Philippines", "Singapore", "Thailand", "Vietnam")
		AND a.year >= 2000 AND a.year <= 2021
		AND a.oil_consumption != ""
		AND a.gdp != ""
      group by a.country, a.year
      order by a.country, a.year
     ) x
left join (
            select a.country, a.year,
                   avg(ifnull(z.oil_consumption,0)) moving_avg_oil,
                   avg(ifnull(z.gdp,0)) moving_avg_gdp
            from owid_energy_data a
            left join owid_energy_data z 
				on a.country = z.country
				and z.year between (a.year) and (a.year + 2)
				WHERE a.country IN ("Brunei", "Cambodia", "Indonesia", "Myanmar", "Laos", "Malaysia", "Philippines", "Singapore", "Thailand", "Vietnam")
				AND a.year >= 2000 AND a.year <= 2021
				AND a.oil_consumption != ""
				AND a.gdp != ""
            group by a.country, a.year
            order by a.country, a.year
		) y 
		on x.country = y.country
		and x.year = y.year + 1
order by x.country, x.year;

-- Q6
/* For importsofenergyproducts */
SELECT energy_products, sub_products, AVG(value_ktoe) 
FROM importsofenergyproducts 
GROUP BY energy_products, sub_products; 
 
 /* For exportsofenergyproducts */
SELECT energy_products, sub_products, AVG(value_ktoe) 
FROM exportsofenergyproducts 
GROUP BY energy_products, sub_products; 

-- Q7
/* Yearly Difference */
WITH import AS 
(SELECT year, 
CONCAT(energy_products, '-', sub_products) product, 
CAST(value_ktoe AS FLOAT) value 
FROM importsofenergyproducts), export 
AS (SELECT year, 
CONCAT(energy_products, '-', sub_products) product, 
CAST(value_ktoe AS FLOAT) value 
FROM exportsofenergyproducts) 
SELECT i.year, i.product, e.value - i.value export_sub_import 
FROM import i 
INNER JOIN export e ON ( 
i.product = e.product AND 
i.year = e.year); 

/* Years where export > import for more than 4 instances */
WITH import AS 
(SELECT year, 
CONCAT(energy_products, '/', sub_products) product, 
CAST(value_ktoe AS FLOAT) value 
FROM importsofenergyproducts), export AS 
(SELECT year, 
CONCAT(energy_products, '/', sub_products) product, 
CAST(value_ktoe AS FLOAT) value 
FROM exportsofenergyproducts) 
SELECT i.year, COUNT(*) instances 
FROM import i 
INNER JOIN export e ON ( 
i.product = e.product AND 
i.year = e.year) 
WHERE e.value > i.value 
GROUP BY i.year 
HAVING instances > 4;

-- Q8
SELECT region, year, AVG(cast(kwh_per_acc as decimal(10,3))) as "Yearly Average kwh-per-acc"
FROM householdelectricityconsumption
WHERE region != "Overall" AND dwelling_type != "Overall" AND month = "Annual" AND kwh_per_acc != "s"
GROUP BY region, year;

-- how to come up with WHERE statement:

-- 1
SELECT distinct(dwelling_type) FROM householdelectricityconsumption;
-- will see "overall"

-- example 1:
-- data: Overall; 2012; 1; Central Region; Bishan; 427
SELECT AVG(cast(kwh_per_acc as decimal(10,3)))
FROM householdelectricityconsumption
WHERE cast(year AS unsigned) = "2012" AND cast(month AS unsigned) = "1" AND region = "Central Region" AND Description = "Bishan";
-- will give 414.32 as output

-- example 2:
-- data: Overall; 2012; 1; Central Region; Bukit Merah; 332.6
SELECT AVG(cast(kwh_per_acc as decimal(10,3)))
FROM householdelectricityconsumption
WHERE cast(year AS unsigned) = "2012" AND cast(month AS unsigned) = "1" AND region = "Central Region" AND Description = "Bukit Merah";
-- will give 480.03 as output

-- the above shows that "overall" dwelling type does not give us the average kwh for all dwelling types in each region, thus we need to exclude it from our computation
-- 2
SELECT distinct(month) FROM householdelectricityconsumption;
-- will see "Annual" --> use this for direct avg of all months

-- example 1: 
-- data: 4 room; 2009; Annual; Central Region; Tanglin	; 426.8
SELECT AVG(cast(kwh_per_acc as decimal(10,3)))
FROM householdelectricityconsumption
WHERE dwelling_type = "4 room" AND cast(year AS unsigned) = "2009" AND month != "Annual" AND region = "Central Region" AND Description = "Tanglin";
-- will give 426.7667 as output --> close to 426.8 from month = "Annual"

-- example 2: 
-- data: 1 room and 2 room	; 2011; Annual; West Region; Choa Chu Kang; 159.2
SELECT AVG(cast(kwh_per_acc as decimal(10,3)))
FROM householdelectricityconsumption
WHERE dwelling_type = "1 room and 2 room" AND cast(year AS unsigned) = "2011" AND month != "Annual" AND region = "West Region" AND Description = "Choa Chu Kang";
-- will give 158.83 as output --> close to 159.2 from month = "Annual"

-- example 3: 
-- data: Public Housing; 2021; Annual; West Region; Jurong East; 357
SELECT AVG(cast(kwh_per_acc as decimal(10,3)))
FROM householdelectricityconsumption
WHERE dwelling_type = "Public Housing" AND cast(year AS unsigned) = "2021" AND month != "Annual" AND region = "West Region" AND Description = "Jurong East";
-- will give 356.95 as output --> close to 357 from month = "Annual"

-- the above shows that month = "Annual" gives us the average kwh for all months of a particular dwelling type, year, region & description, thus we can use it to compute the average kwh_per_acc, instead of computing the averages from months 1-12
-- 3
SELECT distinct(kwh_per_acc) FROM householdelectricityconsumption;
-- kwh_per_acc data of some Descriptions are "s" --> not numeric
-- we need to exclude these "s" data, since they are not numeric and may affect our computations

-- Q9
-- To find list of distinct regions
select distinct region
from householdelectricityconsumption
where region <> "Overall";

-- To find each region's number of negative moving average difference
select region, sum(case when moving_2_year_avg_diff < 0 then 1 else 0 end) no_of_negatives
from (
select region, year, 
avg(cast(kwh_per_acc as double)) average_kwh_per_acc,
avg(cast(kwh_per_acc as double)) - lag(avg(cast(kwh_per_acc as double))) 
	over(order by year) moving_2_year_avg_diff
from householdelectricityconsumption
where month = "Annual"
and region = "Central Region"
group by region, year
) X
group by region;

-- To combine each region's output to display as single result grid using union
(
select region, sum(case when moving_2_year_avg_diff < 0 then 1 else 0 end) no_of_negatives
from (
select region, year, 
avg(cast(kwh_per_acc as double)) average_kwh_per_acc,
avg(cast(kwh_per_acc as double)) - lag(avg(cast(kwh_per_acc as double))) 
	over(order by year) moving_2_year_avg_diff
from householdelectricityconsumption
where month = "Annual"
and region = "Central Region"
group by region, year
) X
group by region
)
union
(
select region, sum(case when moving_2_year_avg_diff < 0 then 1 else 0 end) no_of_negatives
from (
select region, year, 
avg(cast(kwh_per_acc as double)) average_kwh_per_acc,
avg(cast(kwh_per_acc as double)) - lag(avg(cast(kwh_per_acc as double))) 
	over(order by year) moving_2_year_avg_diff
from householdelectricityconsumption
where month = "Annual"
and region = "East Region"
group by region, year
) X
group by region
)
union
(
select region, sum(case when moving_2_year_avg_diff < 0 then 1 else 0 end) no_of_negatives
from (
select region, year, 
avg(cast(kwh_per_acc as double)) average_kwh_per_acc,
avg(cast(kwh_per_acc as double)) - lag(avg(cast(kwh_per_acc as double))) 
	over(order by year) moving_2_year_avg_diff
from householdelectricityconsumption
where month = "Annual"
and region = "North East Region"
group by region, year
) X
group by region
)
union
(
select region, sum(case when moving_2_year_avg_diff < 0 then 1 else 0 end) no_of_negatives
from (
select region, year, 
avg(cast(kwh_per_acc as double)) average_kwh_per_acc,
avg(cast(kwh_per_acc as double)) - lag(avg(cast(kwh_per_acc as double))) 
	over(order by year) moving_2_year_avg_diff
from householdelectricityconsumption
where month = "Annual"
and region = "North Region"
group by region, year
) X
group by region
)
union
(
select region, sum(case when moving_2_year_avg_diff < 0 then 1 else 0 end) no_of_negatives
from (
select region, year, 
avg(cast(kwh_per_acc as double)) average_kwh_per_acc,
avg(cast(kwh_per_acc as double)) - lag(avg(cast(kwh_per_acc as double))) 
	over(order by year) moving_2_year_avg_diff
from householdelectricityconsumption
where month = "Annual"
and region = "West Region"
group by region, year
) X
group by region
)
order by no_of_negatives desc
limit 3;


-- Q10
#to visualize seasonal (quarterly) effects on energy consumption
SELECT cast(year as year) year, region, avg(cast(kwh_per_acc as double)) avg_kwh_per_acc,
case
	when month in ("1","2","3") then "1st Quarter"
    when month in ("4","5","6") then "2nd Quarter"
	when month in ("7","8","9") then "3rd Quarter"
	when month in ("10","11","12") then "4th Quarter"
end as quarters
FROM householdelectricityconsumption
where region != "overall" and month!= "Annual" and kwh_per_acc != "s"
group by cast(year as year), quarters, region with rollup
order by cast(year as year), quarters;

# quarterly average in <kwh_per_acc> for each region
SELECT cast(year as year) year, region, avg(cast(kwh_per_acc as double)) avg_kwh_per_acc,
case
	when month in ("1","2","3") then "1st Quarter"
    when month in ("4","5","6") then "2nd Quarter"
	when month in ("7","8","9") then "3rd Quarter"
	when month in ("10","11","12") then "4th Quarter"
end as quarters
FROM householdelectricityconsumption
where region != "overall" and month != "Annual" and kwh_per_acc != "s"
group by cast(year as year), region, quarters
order by cast(year as year), quarters;

-- Q11
SELECT year, sub_housing_type, avg((avg_mthly_hh_tg_consp_kwh)) as avg_quarter,
case
    when month in('1','2','3') then '1st Quarter'
    when month in('4','5','6') then '2nd Quarter'
    when month in('7','8','9') then '3rd Quarter'
    when month in('10','11','12') then '4th Quarter'
end as quarters
FROM householdtowngasconsumption
where sub_housing_type != "overall" 
group by year, sub_housing_type, quarters;

-- Q14
select country, year,
sum(coal_consumption),
sum(fossil_fuel_consumption),
sum(gas_consumption),
sum(hydro_consumption),
sum(low_carbon_consumption),
sum(nuclear_consumption),
sum(oil_consumption),
sum(other_renewable_consumption),
sum(renewables_consumption),
sum(solar_consumption),
sum(wind_consumption)
from owid_energy_data
where country = "Singapore"
and year = 2020
group by country;
